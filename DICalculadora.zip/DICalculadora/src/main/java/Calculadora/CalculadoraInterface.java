package Calculadora;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CalculadoraInterface extends JFrame implements ActionListener{

    //North pane objects

    JLabel titleText = new JLabel("Tabla de Multiplicar");

    JComboBox barOptions = new JComboBox();

    //Center pane objects

    JButton[] buttons = new JButton[10];

    //South pane objects

    JLabel numberText1;
    JLabel numberText2;
    JLabel resultText;








    public CalculadoraInterface() {

        //North pane

        JPanel northPane = new JPanel();
        northPane.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        northPane.add(titleText);
        c.gridy=1;
        c.weightx=3;
        c.fill = GridBagConstraints.HORIZONTAL;
        northPane.add(barOptions, c);

        this.add(northPane,BorderLayout.NORTH);

        for (int i=0; i<10; i++){
            barOptions.addItem(i);
        }

        //Center pane

        JPanel centerPane = new JPanel();
        centerPane.setLayout(new GridLayout(10,3));


        for(int i=0; i<10; i++){
            buttons[i] = new JButton(String.valueOf(i));
            centerPane.add(buttons[i]);
            buttons[i] = new JButton("=");
            centerPane.add(buttons[i]);
            buttons[i] = new JButton("");
            centerPane.add(buttons[i]);
        }

        this.add(centerPane,BorderLayout.CENTER);

        //South pane

        JPanel southPane = new JPanel();
        southPane.setLayout(new GridBagLayout());

        southPane.add(numberText1);
        southPane.add(numberText2);
        southPane.add(resultText);



        this.add(southPane, BorderLayout.SOUTH);

        this.setTitle("Tabla de Multiplicar");
        this.setSize(350, 350);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);

    }

    public static void main(String[] args) {

        CalculadoraInterface frame = new CalculadoraInterface();

    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
